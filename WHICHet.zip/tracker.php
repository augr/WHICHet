<?php

//Insert the destination page and timestamp into your database
  
//Redirect the user to their intended location

 
?>