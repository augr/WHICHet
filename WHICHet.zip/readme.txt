CHANGELOG
===============================
v0.1.2 - 06.06.14
*Added support for ga.js Google Analytics legacy event tracking